<?php

namespace Hydra\Decorators;

use Hydra\Decorators\DecoratorInterface;

abstract class Decorator {
    public function __construct($field, $type) {

    }
}