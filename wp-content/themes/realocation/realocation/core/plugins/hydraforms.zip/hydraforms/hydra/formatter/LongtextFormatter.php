<?php

namespace Hydra\Formatter;

use Hydra\Builder;

// nothing special about this
class LongtextFormatter extends Formatter {
    public function __construct() {
        $this->name = 'longtext';
    }
}
