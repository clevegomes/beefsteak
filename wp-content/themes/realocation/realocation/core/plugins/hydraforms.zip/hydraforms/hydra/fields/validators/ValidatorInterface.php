<?php

namespace Hydra\Fields\Validators;

interface ValidatorInterface {
    public function validate();
}