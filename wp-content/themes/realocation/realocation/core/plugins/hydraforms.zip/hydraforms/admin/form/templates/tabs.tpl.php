<?php

?>
<div class="tabs tabs-hydra">
  <ul class="fields">
    <li><?php print $this->createLink($tabs['fields']['title'], $tabs['fields']['link']); ?>
    <li><?php print $this->createLink($tabs['handlers']['title'], $tabs['handlers']['link']); ?>
  </ul>
</div>
