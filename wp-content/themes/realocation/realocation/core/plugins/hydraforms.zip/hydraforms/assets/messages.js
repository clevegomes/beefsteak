jQuery(document).ready(function() {
//    jQuery.ajax({
//        dataType: "json",
//        url: '/submit/',
//        success: function(data) {
//            jQuery('#wp-content-wrap').prepend(data.form_messages);
//        }
//    });
});




