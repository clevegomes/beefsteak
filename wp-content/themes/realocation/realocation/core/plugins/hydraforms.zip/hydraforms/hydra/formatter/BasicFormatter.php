<?php

namespace Hydra\Formatter;

class BasicFormatter extends Formatter {
    public function __construct() {
        $this->name = 'basic';
    }
}